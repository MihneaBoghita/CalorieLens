﻿using CalorieLens.Views;
using CalorieLens.Views.CalorieLens.Views;
using Microsoft.Maui.Media;

namespace CalorieLens
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnOpenCamera(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new CameraPage());
        }
    }
}
