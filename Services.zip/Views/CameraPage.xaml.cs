namespace CalorieLens.Views;
using CommunityToolkit.Maui.Views;

namespace CalorieLens.Views;

public partial class CameraPage : ContentPage
{
    public CameraPage()
    {
        InitializeComponent();
    }

    private async void OnCaptureClicked(object sender, EventArgs e)
    {
        if (cameraView.SelectedCamera == null)
            return;

        var photo = await cameraView.CaptureImage(CancellationToken.None);

        if (photo == null)
            return;

        var filePath = Path.Combine(FileSystem.CacheDirectory, "food.jpg");

        using var fileStream = File.OpenWrite(filePath);
        await photo.CopyToAsync(fileStream);

        await DisplayAlert("Success", "Image captured!", "OK");

        // aici vei trimite poza la AI
        await AnalyzeFood(filePath);
    }

    private async Task AnalyzeFood(string imagePath)
    {
        var result = await FoodAIService.AnalyzeFood(imagePath);

        await DisplayAlert("Food Detected", result, "OK");
    }
}
}